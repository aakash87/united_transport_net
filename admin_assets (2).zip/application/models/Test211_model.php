<?php
		    class Test211_model extends MY_Model{

		    	}