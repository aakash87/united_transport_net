<?php 

class Home_model extends MY_Model
{
	
}