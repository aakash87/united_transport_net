<?php
		    class Client_model extends MY_Model{

		    	}