<?php
		    class Blog_category_model extends MY_Model{

		    	}