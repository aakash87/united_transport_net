               <section style="background-color: #3D4C6F;">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4">
                 
        <img class="alignnone size-medium wp-image-15673" src="http://compare-nb.com/clinision/wp-content/uploads/2018/04/logofooter.png" alt="" width="243" height="56">
<p style="    margin-left: 7px;
    margin-top: 12px;
    color: #fff;
    width: 234px;
    font-size: 11px;
    text-align: justify;"><strong>Clinision</strong> provides the comprehensive research solution from all aspects. Whether it’s clinical study management.</p>


                    </div>
                    <div class="col-lg-2">
                       <h5 style="color: #e0e0e0;">Heading 1</h5>
                       <h5 style="color: #e0e0e0; font-size: 18px;">Heading 2</h5>
                       <h5 style="color: #e0e0e0; font-size: 14px;">Heading 3</h5>
                     
                    </div>
                    <div class="col-lg-2">
                       <h5 style="color: #e0e0e0;">Heading 1</h5>
                       <h5 style="color: #e0e0e0; font-size: 18px;">Heading 2</h5>
                       <h5 style="color: #e0e0e0; font-size: 14px;">Heading 3</h5>
                     
                    </div><div class="col-lg-2">
                       <h5 style="color: #e0e0e0;">Heading 1</h5>
                       <h5 style="color: #e0e0e0; font-size: 18px;">Heading 2</h5>
                       <h5 style="color: #e0e0e0; font-size: 14px;">Heading 3</h5>
                     
                    </div>
                </div>
                <!--/.row-->
            </div>
            <!--/.container-->
        </section>
        <section class="background-primary text-center py-4">
            <div class="container">
                <div class="row align-items-center" style="opacity: 0.85;">
                 
                    <div class="col-sm-6 mt-3 mt-sm-0 text-sm-left">
                        <p class="color-white lh-6 mb-0 fw-600">&copy; Copyright 2018 Magma.</p>
                    </div>
                    <div class="col text-sm-right mt-3 mt-sm-0"><a class="color-white" href="https://themewagon.com/" target="_blank"> </a></div>
                </div>
                <!--/.row-->
            </div>
            <!--/.container-->
        </section>
    </main>
    <!--  -->
    <!--    JavaScripts-->
    <!--    =============================================-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
    <script src="<?php echo base_url() ?>front_assets/lib/jquery/dist/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="<?php echo base_url() ?>front_assets/lib/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>front_assets/lib/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo base_url() ?>front_assets/lib/gsap/src/minified/TweenMax.min.js"></script>
    <script src="<?php echo base_url() ?>front_assets/lib/gsap/src/minified/plugins/ScrollToPlugin.min.js"></script>
    <script src="<?php echo base_url() ?>front_assets/lib/CustomEase.min.js"></script>
    <script src="<?php echo base_url() ?>front_assets/js/config.js"></script>
    <script src="<?php echo base_url() ?>front_assets/js/zanimation.js"></script>
    <!-- Hotjar Tracking Code for http://markup.themewagon.com/tryelixir-->
    <script>
        (function(h, o, t, j, a, r) {
            h.hj = h.hj || function() {
                (h.hj.q = h.hj.q || []).push(arguments)
            };
            h._hjSettings = {
                hjid: 710415,
                hjsv: 6
            };
            a = o.getElementsByTagName('head')[0];
            r = o.createElement('script');
            r.async = 1;
            r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv;
            a.appendChild(r);
        })(window, document, 'https://static.hotjar.com/c/hotjar-', '.js?sv=');
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics-->
    <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-76729372-5"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'UA-76729372-5');
    </script>
    <script src="<?php echo base_url() ?>front_assets/lib/remodal/dist/remodal.js"></script>
    <script src="<?php echo base_url() ?>front_assets/js/core.js"></script>
    <script src="<?php echo base_url() ?>front_assets/js/main.js"></script>
</body>

</html>