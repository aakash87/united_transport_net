<?php
		    class Contact_model extends MY_Model{

		    	}