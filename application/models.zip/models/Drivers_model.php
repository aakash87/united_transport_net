<?php
		    class Drivers_model extends MY_Model{

		    	}