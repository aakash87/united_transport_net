<?php
		    class Vehicel_owner_model extends MY_Model{

		    	}