<?php
		    class Service_model extends MY_Model{

		    	}