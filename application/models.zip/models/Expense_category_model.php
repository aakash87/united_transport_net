<?php

		    class Expense_category_model extends MY_Model{



		    	}