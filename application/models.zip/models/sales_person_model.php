<?php
class sales_person_model extends MY_Model{

	}