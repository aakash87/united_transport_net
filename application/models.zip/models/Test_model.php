<?php
		    class Test_model extends MY_Model{

		    	}