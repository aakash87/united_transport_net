<?php
		    class Testing_model extends MY_Model{

		    	}