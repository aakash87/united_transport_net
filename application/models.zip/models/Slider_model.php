<?php
		    class Slider_model extends MY_Model{

		    	}